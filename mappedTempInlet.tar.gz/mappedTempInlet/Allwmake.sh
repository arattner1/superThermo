#!/bin/bash

#Build script for superThermo Library
wmake libso

